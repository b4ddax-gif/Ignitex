package com.example

import com.example.alarm.AlarmTimeCalculator
import com.example.calendar.CalendarScheduler
import com.example.data.database.AlarmEntity
import com.example.data.database.CalendarEventEntity
import com.example.data.database.StreakEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.temporal.ChronoUnit

class IgniteLogicTest {

    @Test
    fun testOneTimeAlarmLaterToday() {
        val zoneId = ZoneId.systemDefault()
        val fixedNow = LocalDate.of(2026, 10, 1).atTime(6, 0).atZone(zoneId).toInstant().toEpochMilli()

        val alarm = AlarmEntity(hour = 7, minute = 30) // 7:30 AM today
        val nextTrigger = AlarmTimeCalculator.calculateNextTriggerTime(alarm, fixedNow)

        val triggerDateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(nextTrigger), zoneId)
        assertEquals(2026, triggerDateTime.year)
        assertEquals(10, triggerDateTime.monthValue)
        assertEquals(1, triggerDateTime.dayOfMonth)
        assertEquals(7, triggerDateTime.hour)
        assertEquals(30, triggerDateTime.minute)
    }

    @Test
    fun testOneTimeAlarmEarlierTodayRingsTomorrow() {
        val zoneId = ZoneId.systemDefault()
        val fixedNow = LocalDate.of(2026, 10, 1).atTime(9, 0).atZone(zoneId).toInstant().toEpochMilli()

        val alarm = AlarmEntity(hour = 7, minute = 0) // 7:00 AM was earlier today
        val nextTrigger = AlarmTimeCalculator.calculateNextTriggerTime(alarm, fixedNow)

        val triggerDateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(nextTrigger), zoneId)
        assertEquals(2, triggerDateTime.dayOfMonth) // Tomorrow!
        assertEquals(7, triggerDateTime.hour)
        assertEquals(0, triggerDateTime.minute)
    }

    @Test
    fun testDateSpecificAlarmFuture() {
        val zoneId = ZoneId.systemDefault()
        val fixedNow = LocalDate.of(2026, 10, 1).atTime(6, 0).atZone(zoneId).toInstant().toEpochMilli()

        val alarm = AlarmEntity(
            hour = 7,
            minute = 0,
            specificDate = "2026-12-25"
        )
        val nextTrigger = AlarmTimeCalculator.calculateNextTriggerTime(alarm, fixedNow)

        val triggerDateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(nextTrigger), zoneId)
        assertEquals(2026, triggerDateTime.year)
        assertEquals(12, triggerDateTime.monthValue)
        assertEquals(25, triggerDateTime.dayOfMonth)
        assertEquals(7, triggerDateTime.hour)
    }

    @Test
    fun testDateSpecificAlarmPastReturnsNegative() {
        val zoneId = ZoneId.systemDefault()
        val fixedNow = LocalDate.of(2026, 12, 26).atTime(6, 0).atZone(zoneId).toInstant().toEpochMilli()

        val alarm = AlarmEntity(
            hour = 7,
            minute = 0,
            specificDate = "2026-12-25"
        )
        val nextTrigger = AlarmTimeCalculator.calculateNextTriggerTime(alarm, fixedNow)
        assertEquals(-1L, nextTrigger)
    }

    @Test
    fun testRepeatDaysSummary() {
        assertEquals("Every day", AlarmTimeCalculator.getRepeatDaysSummary("1,2,3,4,5,6,7"))
        assertEquals("Weekdays", AlarmTimeCalculator.getRepeatDaysSummary("1,2,3,4,5"))
        assertEquals("Weekends", AlarmTimeCalculator.getRepeatDaysSummary("6,7"))
        assertEquals("Once", AlarmTimeCalculator.getRepeatDaysSummary(""))
        assertEquals("On 2026-12-25", AlarmTimeCalculator.getRepeatDaysSummary("1,2", "2026-12-25"))
    }

    @Test
    fun testCalendarReminderTimeCalculation() {
        val event = CalendarEventEntity(
            title = "Team Meeting",
            date = "2026-10-15",
            startTime = "14:00",
            reminder = "15_MIN"
        )

        val reminderTime = CalendarScheduler.calculateReminderTime(event)
        val zoneId = ZoneId.systemDefault()
        val reminderDateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(reminderTime), zoneId)

        assertEquals(13, reminderDateTime.hour)
        assertEquals(45, reminderDateTime.minute)
    }

    @Test
    fun testStreakLogic() {
        // First wake
        var streak = StreakEntity(currentStreak = 0, longestStreak = 0, totalAlarmsCompleted = 0)
        val today = LocalDate.of(2026, 10, 1)

        val updatedStreak1 = streak.copy(
            currentStreak = 1,
            longestStreak = 1,
            totalAlarmsCompleted = 1,
            lastWakeDate = today.toString()
        )
        assertEquals(1, updatedStreak1.currentStreak)

        // Consecutive day
        val tomorrow = today.plusDays(1)
        val daysBetween = ChronoUnit.DAYS.between(LocalDate.parse(updatedStreak1.lastWakeDate), tomorrow)
        assertEquals(1L, daysBetween)

        val updatedStreak2 = updatedStreak1.copy(
            currentStreak = updatedStreak1.currentStreak + 1,
            longestStreak = maxOf(updatedStreak1.longestStreak, updatedStreak1.currentStreak + 1),
            totalAlarmsCompleted = updatedStreak1.totalAlarmsCompleted + 1,
            lastWakeDate = tomorrow.toString()
        )
        assertEquals(2, updatedStreak2.currentStreak)
        assertEquals(2, updatedStreak2.longestStreak)
        assertEquals(2, updatedStreak2.totalAlarmsCompleted)

        // Broken streak (3 days later)
        val future = tomorrow.plusDays(3)
        val brokenDays = ChronoUnit.DAYS.between(LocalDate.parse(updatedStreak2.lastWakeDate), future)
        assertTrue(brokenDays > 1)

        val updatedStreak3 = updatedStreak2.copy(
            currentStreak = 1,
            longestStreak = updatedStreak2.longestStreak,
            totalAlarmsCompleted = updatedStreak2.totalAlarmsCompleted + 1,
            lastWakeDate = future.toString()
        )
        assertEquals(1, updatedStreak3.currentStreak)
        assertEquals(2, updatedStreak3.longestStreak)
        assertEquals(3, updatedStreak3.totalAlarmsCompleted)
    }

    @Test
    fun testFullDayAlarmsDistinction() {
        val zoneId = ZoneId.systemDefault()
        // Assume now is 10:00 AM on 2026-10-01
        val fixedNow = LocalDate.of(2026, 10, 1).atTime(10, 0).atZone(zoneId).toInstant().toEpochMilli()

        // 12:00 PM (Noon today -> in future today)
        val noonAlarm = AlarmEntity(hour = 12, minute = 0)
        val noonTrigger = AlarmTimeCalculator.calculateNextTriggerTime(noonAlarm, fixedNow)
        val noonDateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(noonTrigger), zoneId)
        assertEquals(1, noonDateTime.dayOfMonth)
        assertEquals(12, noonDateTime.hour)
        assertEquals(0, noonDateTime.minute)

        // 12:45 PM (Early afternoon today -> in future today)
        val afternoonAlarm = AlarmEntity(hour = 12, minute = 45)
        val afternoonTrigger = AlarmTimeCalculator.calculateNextTriggerTime(afternoonAlarm, fixedNow)
        val afternoonDateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(afternoonTrigger), zoneId)
        assertEquals(1, afternoonDateTime.dayOfMonth)
        assertEquals(12, afternoonDateTime.hour)
        assertEquals(45, afternoonDateTime.minute)

        // 06:20 PM (Evening today -> in future today)
        val eveningAlarm = AlarmEntity(hour = 18, minute = 20)
        val eveningTrigger = AlarmTimeCalculator.calculateNextTriggerTime(eveningAlarm, fixedNow)
        val eveningDateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(eveningTrigger), zoneId)
        assertEquals(1, eveningDateTime.dayOfMonth)
        assertEquals(18, eveningDateTime.hour)
        assertEquals(20, eveningDateTime.minute)

        // 11:55 PM (Late night today -> in future today)
        val lateNightAlarm = AlarmEntity(hour = 23, minute = 55)
        val lateNightTrigger = AlarmTimeCalculator.calculateNextTriggerTime(lateNightAlarm, fixedNow)
        val lateNightDateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(lateNightTrigger), zoneId)
        assertEquals(1, lateNightDateTime.dayOfMonth)
        assertEquals(23, lateNightDateTime.hour)
        assertEquals(55, lateNightDateTime.minute)

        // 12:00 AM (Midnight -> 00:00, was earlier today, so should trigger tomorrow at midnight!)
        val midnightAlarm = AlarmEntity(hour = 0, minute = 0)
        val midnightTrigger = AlarmTimeCalculator.calculateNextTriggerTime(midnightAlarm, fixedNow)
        val midnightDateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(midnightTrigger), zoneId)
        assertEquals(2, midnightDateTime.dayOfMonth) // Tomorrow
        assertEquals(0, midnightDateTime.hour) // 00:00 midnight
        assertEquals(0, midnightDateTime.minute)

        // 07:30 AM (was earlier today at 10 AM, so triggers tomorrow at 7:30 AM!)
        val morningAlarm = AlarmEntity(hour = 7, minute = 30)
        val morningTrigger = AlarmTimeCalculator.calculateNextTriggerTime(morningAlarm, fixedNow)
        val morningDateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(morningTrigger), zoneId)
        assertEquals(2, morningDateTime.dayOfMonth)
        assertEquals(7, morningDateTime.hour)
        assertEquals(30, morningDateTime.minute)
    }

    @Test
    fun testTimeFormatterDistinguishesMidnightAndNoon() {
        assertEquals("12:00 AM", com.example.ui.components.TimeFormatter.formatTime(0, 0, false))
        assertEquals("12:00 PM", com.example.ui.components.TimeFormatter.formatTime(12, 0, false))
        assertEquals("07:30 AM", com.example.ui.components.TimeFormatter.formatTime(7, 30, false))
        assertEquals("12:45 PM", com.example.ui.components.TimeFormatter.formatTime(12, 45, false))
        assertEquals("06:20 PM", com.example.ui.components.TimeFormatter.formatTime(18, 20, false))
        assertEquals("11:55 PM", com.example.ui.components.TimeFormatter.formatTime(23, 55, false))

        // 24-hour mode
        assertEquals("00:00", com.example.ui.components.TimeFormatter.formatTime(0, 0, true))
        assertEquals("12:00", com.example.ui.components.TimeFormatter.formatTime(12, 0, true))
        assertEquals("07:30", com.example.ui.components.TimeFormatter.formatTime(7, 30, true))
        assertEquals("12:45", com.example.ui.components.TimeFormatter.formatTime(12, 45, true))
        assertEquals("18:20", com.example.ui.components.TimeFormatter.formatTime(18, 20, true))
        assertEquals("23:55", com.example.ui.components.TimeFormatter.formatTime(23, 55, true))
    }
}
