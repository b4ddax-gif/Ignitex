package com.example.alarm

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AlarmAudioPlayer(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private var audioManager: AudioManager =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null
    private var gradualVolumeJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    fun play(soundUriString: String?, gradualVolume: Boolean) {
        stop()

        requestAudioFocus()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        var player: MediaPlayer? = null

        // 1. Try user selected custom sound URI
        if (!soundUriString.isNullOrBlank()) {
            try {
                val uri = Uri.parse(soundUriString)
                player = MediaPlayer().apply {
                    setAudioAttributes(audioAttributes)
                    setDataSource(context, uri)
                    isLooping = true
                    prepare()
                }
            } catch (e: Exception) {
                Log.w("AlarmAudioPlayer", "Failed to load custom sound URI: $soundUriString, falling back", e)
                player?.release()
                player = null
            }
        }

        // 2. Fallback to default system alarm ringtone
        if (player == null) {
            try {
                var alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                if (alarmUri == null) {
                    alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                }
                if (alarmUri == null) {
                    alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                }

                if (alarmUri != null) {
                    player = MediaPlayer().apply {
                        setAudioAttributes(audioAttributes)
                        setDataSource(context, alarmUri)
                        isLooping = true
                        prepare()
                    }
                }
            } catch (e: Exception) {
                Log.e("AlarmAudioPlayer", "Failed to load fallback ringtone", e)
                player?.release()
                player = null
            }
        }

        if (player != null) {
            mediaPlayer = player
            try {
                if (gradualVolume) {
                    player.setVolume(0.1f, 0.1f)
                    player.start()
                    startGradualVolume(player)
                } else {
                    player.setVolume(1.0f, 1.0f)
                    player.start()
                }
            } catch (e: Exception) {
                Log.e("AlarmAudioPlayer", "Error starting media player", e)
            }
        }
    }

    private fun startGradualVolume(player: MediaPlayer) {
        gradualVolumeJob?.cancel()
        gradualVolumeJob = scope.launch {
            var currentVol = 0.1f
            while (isActive && currentVol < 1.0f) {
                delay(2000L) // Increase every 2 seconds
                currentVol = (currentVol + 0.05f).coerceAtMost(1.0f)
                try {
                    player.setVolume(currentVol, currentVol)
                } catch (e: Exception) {
                    break
                }
            }
        }
    }

    private fun requestAudioFocus() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val attributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()

                audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                    .setAudioAttributes(attributes)
                    .setAcceptsDelayedFocusGain(true)
                    .setOnAudioFocusChangeListener { /* maintain alarm */ }
                    .build()

                audioManager.requestAudioFocus(audioFocusRequest!!)
            } else {
                @Suppress("DEPRECATION")
                audioManager.requestAudioFocus(
                    null,
                    AudioManager.STREAM_ALARM,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE
                )
            }
        } catch (e: Exception) {
            Log.e("AlarmAudioPlayer", "Error requesting audio focus", e)
        }
    }

    fun stop() {
        gradualVolumeJob?.cancel()
        gradualVolumeJob = null

        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.reset()
                it.release()
            }
        } catch (e: Exception) {
            Log.e("AlarmAudioPlayer", "Error stopping player", e)
        } finally {
            mediaPlayer = null
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(null)
            }
        } catch (e: Exception) {
            Log.e("AlarmAudioPlayer", "Error abandoning audio focus", e)
        }
    }
}
