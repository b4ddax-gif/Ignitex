package com.example.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.database.AlarmEntity

class AlarmScheduler(private val context: Context) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun canScheduleExactAlarms(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
    }

    fun scheduleAlarm(alarm: AlarmEntity, triggerTime: Long? = null) {
        if (!alarm.enabled) {
            cancelAlarm(alarm.id)
            return
        }

        val nextTrigger = triggerTime ?: AlarmTimeCalculator.calculateNextTriggerTime(alarm)
        if (nextTrigger <= System.currentTimeMillis()) {
            Log.w("AlarmScheduler", "Alarm trigger time is in the past for id ${alarm.id}")
            return
        }

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_TRIGGER_ALARM
            putExtra(EXTRA_ALARM_ID, alarm.id)
            putExtra(EXTRA_ALARM_LABEL, alarm.label)
            putExtra(EXTRA_IS_SNOOZE, false)
            putExtra(EXTRA_SNOOZE_COUNT, 0)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            alarm.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        scheduleExact(nextTrigger, pendingIntent, alarm.id)
    }

    fun scheduleSnooze(alarm: AlarmEntity, snoozeMinutes: Int, currentSnoozeCount: Int) {
        val triggerTime = System.currentTimeMillis() + (snoozeMinutes * 60 * 1000L)

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_TRIGGER_ALARM
            putExtra(EXTRA_ALARM_ID, alarm.id)
            putExtra(EXTRA_ALARM_LABEL, alarm.label)
            putExtra(EXTRA_IS_SNOOZE, true)
            putExtra(EXTRA_SNOOZE_COUNT, currentSnoozeCount)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            (alarm.id.toInt() + SNOOZE_REQUEST_CODE_OFFSET),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        scheduleExact(triggerTime, pendingIntent, alarm.id)
    }

    private fun scheduleExact(triggerTime: Long, pendingIntent: PendingIntent, alarmId: Long) {
        try {
            // For real alarms, setAlarmClock provides maximum reliability and shows alarm icon in status bar
            val showIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
            val showPendingIntent = if (showIntent != null) {
                PendingIntent.getActivity(
                    context,
                    alarmId.toInt(),
                    showIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            } else {
                null
            }

            if (showPendingIntent != null) {
                val alarmClockInfo = AlarmManager.AlarmClockInfo(triggerTime, showPendingIntent)
                alarmManager.setAlarmClock(alarmClockInfo, pendingIntent)
            } else {
                if (canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
                }
            }
            Log.d("AlarmScheduler", "Alarm $alarmId scheduled for $triggerTime")
        } catch (e: SecurityException) {
            Log.e("AlarmScheduler", "SecurityException scheduling alarm $alarmId", e)
            try {
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
            } catch (ex: Exception) {
                Log.e("AlarmScheduler", "Failed fallback alarm scheduling", ex)
            }
        } catch (e: Exception) {
            Log.e("AlarmScheduler", "Error scheduling alarm $alarmId", e)
        }
    }

    fun cancelAlarm(alarmId: Long) {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_TRIGGER_ALARM
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            alarmId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)

        // Also cancel any snooze
        val snoozePendingIntent = PendingIntent.getBroadcast(
            context,
            (alarmId.toInt() + SNOOZE_REQUEST_CODE_OFFSET),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(snoozePendingIntent)
    }

    companion object {
        const val ACTION_TRIGGER_ALARM = "com.aistudio.ignite.ACTION_TRIGGER_ALARM"
        const val ACTION_SNOOZE_ALARM = "com.aistudio.ignite.ACTION_SNOOZE_ALARM"
        const val ACTION_DISMISS_ALARM = "com.aistudio.ignite.ACTION_DISMISS_ALARM"

        const val EXTRA_ALARM_ID = "extra_alarm_id"
        const val EXTRA_ALARM_LABEL = "extra_alarm_label"
        const val EXTRA_IS_SNOOZE = "extra_is_snooze"
        const val EXTRA_SNOOZE_COUNT = "extra_snooze_count"

        private const val SNOOZE_REQUEST_CODE_OFFSET = 100000
    }
}
