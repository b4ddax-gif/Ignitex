package com.example.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.IgniteApplication
import com.example.alarm.AlarmScheduler
import com.example.alarm.AlarmTimeCalculator
import com.example.data.database.AlarmEntity
import com.example.data.database.CalendarEventEntity
import com.example.data.database.StreakEntity
import com.example.data.database.TaskEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

data class TimelineItem(
    val id: String,
    val time: String, // "07:00 AM" or "07:00"
    val timeSortKey: Int, // minutes from midnight for sorting
    val title: String,
    val subtitle: String,
    val type: TimelineType,
    val completed: Boolean = false
)

enum class TimelineType {
    ALARM, EVENT, TASK
}

data class HomeUiState(
    val greeting: String = "",
    val currentDateFormatted: String = "",
    val nextAlarm: AlarmEntity? = null,
    val nextAlarmCountdown: String = "",
    val streak: StreakEntity = StreakEntity(),
    val todayAlarms: List<AlarmEntity> = emptyList(),
    val todayEvents: List<CalendarEventEntity> = emptyList(),
    val todayTasks: List<TaskEntity> = emptyList(),
    val timelineItems: List<TimelineItem> = emptyList(),
    val is24Hour: Boolean = false
)

class HomeViewModel : ViewModel() {

    private val app = IgniteApplication.instance
    private val alarmRepo = app.alarmRepository
    private val calendarRepo = app.calendarRepository
    private val taskRepo = app.taskRepository
    private val historyRepo = app.historyRepository
    private val settingsRepo = app.settingsRepository
    private val alarmScheduler = app.alarmScheduler
    private val calendarScheduler = app.calendarScheduler

    private val todayDateStr = LocalDate.now().toString()

    val uiState: StateFlow<HomeUiState> = combine(
        alarmRepo.allAlarms,
        calendarRepo.getEventsForDate(todayDateStr),
        taskRepo.getTasksForDate(todayDateStr),
        historyRepo.streakFlow,
        settingsRepo.is24Hour
    ) { alarms, events, tasks, streak, is24Hour ->
        buildHomeState(alarms, events, tasks, streak ?: StreakEntity(), is24Hour)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState()
    )

    private fun buildHomeState(
        alarms: List<AlarmEntity>,
        events: List<CalendarEventEntity>,
        tasks: List<TaskEntity>,
        streak: StreakEntity,
        is24Hour: Boolean
    ): HomeUiState {
        val now = LocalTime.now()
        val greeting = when (now.hour) {
            in 5..11 -> "Good Morning"
            in 12..16 -> "Good Afternoon"
            in 17..21 -> "Good Evening"
            else -> "Rise & Ignite"
        }

        val dateFormatted = LocalDate.now().format(
            DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy", Locale.getDefault())
        )

        // Find next upcoming alarm
        val enabledAlarms = alarms.filter { it.enabled }
        var nextAlarm: AlarmEntity? = null
        var earliestTrigger = Long.MAX_VALUE
        val nowMillis = System.currentTimeMillis()

        for (alarm in enabledAlarms) {
            val trigger = AlarmTimeCalculator.calculateNextTriggerTime(alarm, nowMillis)
            if (trigger in (nowMillis + 1)..<earliestTrigger) {
                earliestTrigger = trigger
                nextAlarm = alarm
            }
        }

        val nextAlarmCountdown = if (nextAlarm != null && earliestTrigger != Long.MAX_VALUE) {
            val diffMs = earliestTrigger - nowMillis
            val diffMinutes = diffMs / (60 * 1000)
            val hours = diffMinutes / 60
            val mins = diffMinutes % 60
            if (hours > 0) {
                "in ${hours}h ${mins}m"
            } else {
                "in ${mins}m"
            }
        } else {
            "No active alarm"
        }

        // Build Daily Timeline combining alarms, events, and tasks
        val timeline = mutableListOf<TimelineItem>()

        // 1. Alarms scheduled for today
        val todayDow = LocalDate.now().dayOfWeek.value
        for (alarm in enabledAlarms) {
            val isToday = if (!alarm.specificDate.isNullOrBlank()) {
                alarm.specificDate == todayDateStr
            } else if (alarm.repeatDays.isNotBlank()) {
                AlarmTimeCalculator.parseRepeatDays(alarm.repeatDays).contains(todayDow)
            } else {
                // One-time alarm
                true
            }

            if (isToday) {
                val timeStr = formatTime(alarm.hour, alarm.minute, is24Hour)
                timeline.add(
                    TimelineItem(
                        id = "alarm_${alarm.id}",
                        time = timeStr,
                        timeSortKey = alarm.hour * 60 + alarm.minute,
                        title = alarm.label,
                        subtitle = "Alarm • ${alarm.soundName}",
                        type = TimelineType.ALARM
                    )
                )
            }
        }

        // 2. Events for today
        for (event in events) {
            val (h, m) = parseHourMinute(event.startTime)
            val timeStr = if (event.allDay) "All Day" else formatTime(h, m, is24Hour)
            timeline.add(
                TimelineItem(
                    id = "event_${event.id}",
                    time = timeStr,
                    timeSortKey = if (event.allDay) 0 else h * 60 + m,
                    title = event.title,
                    subtitle = if (event.important) "⭐ Important Event" else "Calendar Event",
                    type = TimelineType.EVENT
                )
            )
        }

        // 3. Tasks for today
        for (task in tasks) {
            val sortKey = if (!task.reminderTime.isNullOrBlank()) {
                val (h, m) = parseHourMinute(task.reminderTime)
                h * 60 + m
            } else {
                720 // default noon
            }
            val timeStr = if (!task.reminderTime.isNullOrBlank()) {
                val (h, m) = parseHourMinute(task.reminderTime)
                formatTime(h, m, is24Hour)
            } else {
                "Planner"
            }
            timeline.add(
                TimelineItem(
                    id = "task_${task.id}",
                    time = timeStr,
                    timeSortKey = sortKey,
                    title = task.title,
                    subtitle = "Priority: ${task.priority}",
                    type = TimelineType.TASK,
                    completed = task.completed
                )
            )
        }

        timeline.sortBy { it.timeSortKey }

        return HomeUiState(
            greeting = greeting,
            currentDateFormatted = dateFormatted,
            nextAlarm = nextAlarm,
            nextAlarmCountdown = nextAlarmCountdown,
            streak = streak,
            todayAlarms = enabledAlarms,
            todayEvents = events,
            todayTasks = tasks,
            timelineItems = timeline,
            is24Hour = is24Hour
        )
    }

    private fun formatTime(hour: Int, minute: Int, is24Hour: Boolean): String {
        return if (is24Hour) {
            String.format(Locale.US, "%02d:%02d", hour, minute)
        } else {
            val h = if (hour == 0) 12 else if (hour > 12) hour - 12 else hour
            val amPm = if (hour < 12) "AM" else "PM"
            String.format(Locale.US, "%02d:%02d %s", h, minute, amPm)
        }
    }

    private fun parseHourMinute(time: String): Pair<Int, Int> {
        val parts = time.split(":")
        val h = parts.getOrNull(0)?.toIntOrNull() ?: 9
        val m = parts.getOrNull(1)?.toIntOrNull() ?: 0
        return h to m
    }

    fun toggleTask(id: Long, completed: Boolean) {
        viewModelScope.launch {
            taskRepo.setTaskCompleted(id, completed)
        }
    }

    fun toggleAlarm(id: Long, enabled: Boolean) {
        viewModelScope.launch {
            alarmRepo.toggleAlarm(id, enabled)
            val updated = alarmRepo.getAlarm(id)
            if (updated != null) {
                if (enabled) {
                    alarmScheduler.scheduleAlarm(updated)
                } else {
                    alarmScheduler.cancelAlarm(id)
                }
            }
        }
    }

    fun quickAddAlarm(hour: Int, minute: Int, label: String) {
        viewModelScope.launch {
            val newAlarm = AlarmEntity(
                hour = hour,
                minute = minute,
                label = label.ifBlank { "Quick Alarm" },
                enabled = true
            )
            val id = alarmRepo.insertAlarm(newAlarm)
            alarmScheduler.scheduleAlarm(newAlarm.copy(id = id))
        }
    }

    fun quickAddEvent(title: String, time: String) {
        viewModelScope.launch {
            val newEvent = CalendarEventEntity(
                title = title.ifBlank { "Event" },
                date = todayDateStr,
                startTime = time,
                endTime = time
            )
            val id = calendarRepo.insertEvent(newEvent)
            calendarScheduler.scheduleEventReminder(newEvent.copy(id = id))
        }
    }

    fun quickAddTask(title: String, priority: String) {
        viewModelScope.launch {
            val newTask = TaskEntity(
                title = title.ifBlank { "New Task" },
                date = todayDateStr,
                priority = priority
            )
            taskRepo.insertTask(newTask)
        }
    }
}
