package com.example.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object Home : Screen("home", "Home")
    object Alarms : Screen("alarms", "Alarms")
    object Calendar : Screen("calendar", "Calendar")
    object Settings : Screen("settings", "Settings")
    object AlarmHistory : Screen("alarm_history", "Alarm History")
}
