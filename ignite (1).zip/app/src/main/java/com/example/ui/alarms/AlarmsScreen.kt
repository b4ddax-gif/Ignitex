package com.example.ui.alarms

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.alarm.AlarmTimeCalculator
import com.example.data.database.AlarmEntity
import com.example.ui.components.IgniteCard
import com.example.ui.components.TimeFormatter
import com.example.ui.theme.IgniteBackground
import com.example.ui.theme.IgniteFlameContainer
import com.example.ui.theme.IgniteFlameOrange
import com.example.ui.theme.IgniteFlamePrimary
import com.example.ui.theme.IgniteSurface
import com.example.ui.theme.IgniteSurfaceVariant
import com.example.ui.theme.IgniteTextMuted
import com.example.ui.theme.IgniteTextPrimary
import com.example.ui.theme.IgniteTextSecondary

@Composable
fun AlarmsScreen(
    onNavigateToHistory: () -> Unit,
    viewModel: AlarmsViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    var editingAlarm by remember { mutableStateOf<AlarmEntity?>(null) }
    var showAddEditSheet by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = IgniteBackground,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingAlarm = null
                    showAddEditSheet = true
                },
                containerColor = IgniteFlamePrimary,
                contentColor = Color.White,
                shape = CircleShape
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Alarm", modifier = Modifier.size(28.dp))
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ALARMS",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        ),
                        color = IgniteTextPrimary
                    )
                    Text(
                        text = "${uiState.alarms.count { it.enabled }} active alarms",
                        style = MaterialTheme.typography.bodySmall,
                        color = IgniteTextSecondary
                    )
                }

                IconButton(
                    onClick = onNavigateToHistory,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(IgniteSurfaceVariant)
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Alarm History",
                        tint = IgniteFlameOrange
                    )
                }
            }

            if (uiState.alarms.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 100.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Alarm,
                            contentDescription = null,
                            tint = IgniteTextMuted,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No Alarms Created",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = IgniteTextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap + to create your first IGNITE alarm",
                            style = MaterialTheme.typography.bodySmall,
                            color = IgniteTextSecondary
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 100.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(uiState.alarms, key = { it.id }) { alarm ->
                        AlarmItemCard(
                            alarm = alarm,
                            is24Hour = uiState.is24Hour,
                            onToggle = { enabled -> viewModel.toggleAlarm(alarm, enabled) },
                            onEdit = {
                                editingAlarm = alarm
                                showAddEditSheet = true
                            },
                            onDelete = { viewModel.deleteAlarm(alarm) }
                        )
                    }
                }
            }
        }
    }

    if (showAddEditSheet) {
        AddEditAlarmSheet(
            alarm = editingAlarm,
            is24Hour = uiState.is24Hour,
            onDismiss = { showAddEditSheet = false },
            onSave = { savedAlarm ->
                viewModel.saveAlarm(savedAlarm) {
                    showAddEditSheet = false
                }
            }
        )
    }
}

@Composable
private fun AlarmItemCard(
    alarm: AlarmEntity,
    is24Hour: Boolean,
    onToggle: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    IgniteCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEdit() },
        backgroundColor = if (alarm.enabled) IgniteSurfaceVariant else IgniteSurface
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // Main Time & Toggle Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = TimeFormatter.formatTime(alarm.hour, alarm.minute, is24Hour),
                        style = MaterialTheme.typography.displaySmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = if (alarm.enabled) IgniteTextPrimary else IgniteTextMuted
                    )
                    Text(
                        text = alarm.label,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                        color = if (alarm.enabled) IgniteFlameOrange else IgniteTextMuted
                    )
                }

                Switch(
                    checked = alarm.enabled,
                    onCheckedChange = onToggle,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = IgniteFlamePrimary,
                        checkedTrackColor = IgniteFlameContainer,
                        uncheckedThumbColor = IgniteTextMuted,
                        uncheckedTrackColor = IgniteSurface
                    )
                )
            }

            // Tags / Features Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Repeat badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(IgniteSurface)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = AlarmTimeCalculator.getRepeatDaysSummary(alarm.repeatDays, alarm.specificDate),
                            style = MaterialTheme.typography.labelSmall,
                            color = IgniteTextSecondary
                        )
                    }

                    // Mission badge
                    if (alarm.missionType != "NORMAL") {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(IgniteFlameContainer)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Mission: ${alarm.missionType}",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = IgniteFlameOrange
                            )
                        }
                    }

                    // Sound badge
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = IgniteTextMuted,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = alarm.soundName,
                            style = MaterialTheme.typography.labelSmall,
                            color = IgniteTextMuted,
                            maxLines = 1
                        )
                    }
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Delete Alarm",
                        tint = IgniteTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
