package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = IgniteFlamePrimary,
    onPrimary = Color.White,
    primaryContainer = IgniteFlameContainer,
    onPrimaryContainer = IgniteFlameOrange,
    secondary = IgniteFlameOrange,
    onSecondary = Color.White,
    secondaryContainer = IgniteFlameContainer,
    onSecondaryContainer = IgniteFlameOrange,
    tertiary = IgniteFlameCrimson,
    background = IgniteBackground,
    onBackground = IgniteTextPrimary,
    surface = IgniteSurface,
    onSurface = IgniteTextPrimary,
    surfaceVariant = IgniteSurfaceVariant,
    onSurfaceVariant = IgniteTextSecondary,
    surfaceBright = IgniteSurfaceBright,
    outline = IgniteOutline,
    outlineVariant = IgniteOutlineSubtle
)

private val LightColorScheme = lightColorScheme(
    primary = IgniteFlamePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFECE5),
    onPrimaryContainer = Color(0xFF7A1C00),
    secondary = IgniteFlameOrange,
    onSecondary = Color.White,
    tertiary = IgniteFlameCrimson,
    background = Color(0xFFF9FAFC),
    onBackground = Color(0xFF14161B),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF14161B),
    surfaceVariant = Color(0xFFEEF0F5),
    onSurfaceVariant = Color(0xFF4C5160),
    outline = Color(0xFFD0D5DD)
)

@Composable
fun IGNITETheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
