package com.example.ui.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.database.CalendarEventEntity
import com.example.ui.components.IgniteCard
import com.example.ui.theme.IgniteBackground
import com.example.ui.theme.IgniteFlameContainer
import com.example.ui.theme.IgniteFlameOrange
import com.example.ui.theme.IgniteFlamePrimary
import com.example.ui.theme.IgniteOutline
import com.example.ui.theme.IgniteSurface
import com.example.ui.theme.IgniteTextMuted
import com.example.ui.theme.IgniteTextPrimary
import com.example.ui.theme.IgniteTextSecondary
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddEditEventSheet(
    event: CalendarEventEntity?,
    initialDate: LocalDate,
    onDismiss: () -> Unit,
    onSave: (CalendarEventEntity) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var title by remember { mutableStateOf(event?.title ?: "") }
    var description by remember { mutableStateOf(event?.description ?: "") }
    var note by remember { mutableStateOf(event?.note ?: "") }
    var dateStr by remember { mutableStateOf(event?.date ?: initialDate.toString()) }
    var startTime by remember { mutableStateOf(event?.startTime ?: "09:00") }
    var endTime by remember { mutableStateOf(event?.endTime ?: "10:00") }
    var allDay by remember { mutableStateOf(event?.allDay ?: false) }
    var reminder by remember { mutableStateOf(event?.reminder ?: "AT_TIME") }
    var repeatRule by remember { mutableStateOf(event?.repeatRule ?: "NONE") }
    var important by remember { mutableStateOf(event?.important ?: false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = IgniteBackground,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (event == null) "New Event" else "Edit Event",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = IgniteTextPrimary
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = IgniteTextSecondary)
                }
            }

            // Title
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Event Title") },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IgniteFlamePrimary,
                    unfocusedBorderColor = IgniteOutline,
                    focusedTextColor = IgniteTextPrimary,
                    unfocusedTextColor = IgniteTextPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            // Date & All-Day
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurface
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("All-Day Event", color = IgniteTextPrimary, fontWeight = FontWeight.Medium)
                        Switch(
                            checked = allDay,
                            onCheckedChange = { allDay = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = IgniteFlamePrimary,
                                checkedTrackColor = IgniteFlameContainer
                            )
                        )
                    }

                    OutlinedTextField(
                        value = dateStr,
                        onValueChange = { dateStr = it },
                        label = { Text("Date (YYYY-MM-DD)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IgniteFlamePrimary,
                            unfocusedBorderColor = IgniteOutline,
                            focusedTextColor = IgniteTextPrimary,
                            unfocusedTextColor = IgniteTextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (!allDay) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = startTime,
                                onValueChange = { startTime = it },
                                label = { Text("Start (HH:mm)") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = IgniteFlamePrimary,
                                    unfocusedBorderColor = IgniteOutline,
                                    focusedTextColor = IgniteTextPrimary,
                                    unfocusedTextColor = IgniteTextPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = endTime,
                                onValueChange = { endTime = it },
                                label = { Text("End (HH:mm)") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = IgniteFlamePrimary,
                                    unfocusedBorderColor = IgniteOutline,
                                    focusedTextColor = IgniteTextPrimary,
                                    unfocusedTextColor = IgniteTextPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Important / Star Option (Countdown)
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurface
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (important) Icons.Default.Star else Icons.Outlined.StarBorder,
                            contentDescription = null,
                            tint = if (important) IgniteFlameOrange else IgniteTextMuted
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Important / Starred Event", color = IgniteTextPrimary, fontWeight = FontWeight.SemiBold)
                            Text("Displays countdown on Calendar & Home", style = MaterialTheme.typography.bodySmall, color = IgniteTextMuted)
                        }
                    }
                    Switch(
                        checked = important,
                        onCheckedChange = { important = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = IgniteFlameOrange,
                            checkedTrackColor = IgniteFlameContainer
                        )
                    )
                }
            }

            // Reminder Options
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurface
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Notifications, contentDescription = null, tint = IgniteFlameOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("REMINDER", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = IgniteTextSecondary)
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val reminderOptions = listOf(
                            "NONE" to "None",
                            "AT_TIME" to "At time",
                            "5_MIN" to "5m before",
                            "10_MIN" to "10m before",
                            "15_MIN" to "15m before",
                            "30_MIN" to "30m before",
                            "1_HOUR" to "1h before",
                            "1_DAY" to "1d before"
                        )
                        reminderOptions.forEach { (key, label) ->
                            FilterChip(
                                selected = reminder == key,
                                onClick = { reminder = key },
                                label = { Text(label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IgniteFlameContainer,
                                    selectedLabelColor = IgniteFlameOrange
                                )
                            )
                        }
                    }
                }
            }

            // Repeat Options
            IgniteCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IgniteSurface
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Repeat, contentDescription = null, tint = IgniteFlameOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("REPEAT", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = IgniteTextSecondary)
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val repeatOptions = listOf(
                            "NONE" to "Does not repeat",
                            "DAILY" to "Daily",
                            "WEEKLY" to "Weekly",
                            "MONTHLY" to "Monthly",
                            "YEARLY" to "Yearly"
                        )
                        repeatOptions.forEach { (key, label) ->
                            FilterChip(
                                selected = repeatRule == key,
                                onClick = { repeatRule = key },
                                label = { Text(label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IgniteFlameContainer,
                                    selectedLabelColor = IgniteFlameOrange
                                )
                            )
                        }
                    }
                }
            }

            // Description & Note
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IgniteFlamePrimary,
                    unfocusedBorderColor = IgniteOutline,
                    focusedTextColor = IgniteTextPrimary,
                    unfocusedTextColor = IgniteTextPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Private Note") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IgniteFlamePrimary,
                    unfocusedBorderColor = IgniteOutline,
                    focusedTextColor = IgniteTextPrimary,
                    unfocusedTextColor = IgniteTextPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            // Save Button
            Button(
                onClick = {
                    val saved = (event ?: CalendarEventEntity(
                        title = title.ifBlank { "Event" },
                        date = dateStr
                    )).copy(
                        title = title.ifBlank { "Event" },
                        description = description,
                        note = note,
                        date = dateStr,
                        startTime = startTime,
                        endTime = endTime,
                        allDay = allDay,
                        reminder = reminder,
                        repeatRule = repeatRule,
                        important = important,
                        updatedAt = System.currentTimeMillis()
                    )
                    onSave(saved)
                },
                colors = ButtonDefaults.buttonColors(containerColor = IgniteFlamePrimary),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text("Save Event", fontWeight = FontWeight.Bold, color = Color.White)
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
