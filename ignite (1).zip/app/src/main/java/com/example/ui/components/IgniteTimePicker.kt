package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Brightness4
import androidx.compose.material.icons.filled.Brightness7
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.IgniteFlameContainer
import com.example.ui.theme.IgniteFlameCrimson
import com.example.ui.theme.IgniteFlameOrange
import com.example.ui.theme.IgniteFlamePrimary
import com.example.ui.theme.IgniteOutline
import com.example.ui.theme.IgniteSurface
import com.example.ui.theme.IgniteSurfaceVariant
import com.example.ui.theme.IgniteTextMuted
import com.example.ui.theme.IgniteTextPrimary
import com.example.ui.theme.IgniteTextSecondary
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun IgniteTimePicker(
    hour: Int, // 0..23
    minute: Int, // 0..59
    onTimeChanged: (newHour: Int, newMinute: Int) -> Unit,
    modifier: Modifier = Modifier,
    initialIs24Hour: Boolean = false
) {
    var is24HourMode by remember { mutableStateOf(initialIs24Hour) }

    // Derive 12-hour components
    val isPm = hour >= 12
    val displayHour12 = when {
        hour == 0 -> 12 // Midnight
        hour > 12 -> hour - 12
        else -> hour // 1..12 (12 is noon)
    }

    // Time of day contextual description
    val contextDescription = when {
        hour == 0 && minute == 0 -> "Midnight (00:00)"
        hour == 12 && minute == 0 -> "Noon (12:00)"
        hour in 0..4 -> "Late Night (${String.format(Locale.US, "%02d:%02d", hour, minute)})"
        hour in 5..11 -> "Morning (${String.format(Locale.US, "%02d:%02d", hour, minute)})"
        hour in 12..16 -> "Afternoon (${String.format(Locale.US, "%02d:%02d", hour, minute)})"
        hour in 17..20 -> "Evening (${String.format(Locale.US, "%02d:%02d", hour, minute)})"
        else -> "Night (${String.format(Locale.US, "%02d:%02d", hour, minute)})"
    }

    fun updateFrom12Hour(newDisplayHour12: Int, newIsPm: Boolean) {
        val calculatedHour = if (newIsPm) {
            if (newDisplayHour12 == 12) 12 else newDisplayHour12 + 12
        } else {
            if (newDisplayHour12 == 12) 0 else newDisplayHour12
        }
        onTimeChanged(calculatedHour, minute)
    }

    IgniteCard(
        modifier = modifier.fillMaxWidth(),
        backgroundColor = IgniteSurface
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Mode Header: 12-Hour vs 24-Hour Switcher
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = null,
                        tint = IgniteFlameOrange,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ALARM TIME",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = IgniteTextSecondary
                    )
                }

                // 12h / 24h Toggle Pill
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(IgniteSurfaceVariant)
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (!is24HourMode) IgniteFlamePrimary else Color.Transparent)
                            .clickable { is24HourMode = false }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "12-Hour",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (!is24HourMode) Color.White else IgniteTextSecondary
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (is24HourMode) IgniteFlamePrimary else Color.Transparent)
                            .clickable { is24HourMode = true }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "24-Hour",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (is24HourMode) Color.White else IgniteTextSecondary
                        )
                    }
                }
            }

            // Main Time Display Area
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    // Hour & Minute Digits
                    val hourFormatted = if (is24HourMode) {
                        String.format(Locale.US, "%02d", hour)
                    } else {
                        String.format(Locale.US, "%02d", displayHour12)
                    }
                    val minuteFormatted = String.format(Locale.US, "%02d", minute)

                    Text(
                        text = hourFormatted,
                        style = MaterialTheme.typography.displayLarge.copy(
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 2.sp
                        ),
                        color = IgniteTextPrimary
                    )

                    Text(
                        text = ":",
                        style = MaterialTheme.typography.displayLarge.copy(
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = IgniteFlamePrimary,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )

                    Text(
                        text = minuteFormatted,
                        style = MaterialTheme.typography.displayLarge.copy(
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 2.sp
                        ),
                        color = IgniteTextPrimary
                    )

                    // AM / PM Large Indicator in 12-Hour mode
                    if (!is24HourMode) {
                        Spacer(modifier = Modifier.width(12.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(IgniteFlameContainer)
                                .border(1.dp, IgniteFlamePrimary, RoundedCornerShape(10.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (isPm) "PM" else "AM",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                ),
                                color = IgniteFlameOrange
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Time description badge (e.g. "Noon (12:00)", "Midnight (00:00)")
                Text(
                    text = contextDescription,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                    color = IgniteFlameOrange
                )
            }

            // AM / PM Selection Buttons (only in 12-hour mode)
            if (!is24HourMode) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // AM Button
                    val isAmSelected = !isPm
                    val amBackground by animateColorAsState(
                        if (isAmSelected) IgniteFlamePrimary else IgniteSurfaceVariant,
                        label = "am_bg"
                    )
                    Button(
                        onClick = { updateFrom12Hour(displayHour12, false) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = amBackground,
                            contentColor = if (isAmSelected) Color.White else IgniteTextSecondary
                        )
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Brightness7,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "AM  (Midnight - 11:59 AM)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    // PM Button
                    val isPmSelected = isPm
                    val pmBackground by animateColorAsState(
                        if (isPmSelected) IgniteFlamePrimary else IgniteSurfaceVariant,
                        label = "pm_bg"
                    )
                    Button(
                        onClick = { updateFrom12Hour(displayHour12, true) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = pmBackground,
                            contentColor = if (isPmSelected) Color.White else IgniteTextSecondary
                        )
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Brightness4,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "PM  (Noon - 11:59 PM)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = IgniteOutline)

            // Hour Selection Row
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (is24HourMode) "SELECT HOUR (00 - 23)" else "SELECT HOUR (1 - 12)",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = IgniteTextSecondary
                    )

                    // Step Buttons
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = {
                                if (is24HourMode) {
                                    val newH = if (hour > 0) hour - 1 else 23
                                    onTimeChanged(newH, minute)
                                } else {
                                    val newH12 = if (displayHour12 > 1) displayHour12 - 1 else 12
                                    updateFrom12Hour(newH12, isPm)
                                }
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Minus 1 Hour", tint = IgniteFlameOrange)
                        }
                        IconButton(
                            onClick = {
                                if (is24HourMode) {
                                    val newH = if (hour < 23) hour + 1 else 0
                                    onTimeChanged(newH, minute)
                                } else {
                                    val newH12 = if (displayHour12 < 12) displayHour12 + 1 else 1
                                    updateFrom12Hour(newH12, isPm)
                                }
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Plus 1 Hour", tint = IgniteFlameOrange)
                        }
                    }
                }

                // Hour Chips: 12-hour (1..12) or 24-hour (0..23)
                if (!is24HourMode) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items((1..12).toList()) { h ->
                            val isSelected = displayHour12 == h
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) IgniteFlamePrimary else IgniteSurfaceVariant)
                                    .clickable { updateFrom12Hour(h, isPm) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$h",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = if (isSelected) Color.White else IgniteTextPrimary
                                )
                            }
                        }
                    }
                } else {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items((0..23).toList()) { h ->
                            val isSelected = hour == h
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) IgniteFlamePrimary else IgniteSurfaceVariant)
                                    .clickable { onTimeChanged(h, minute) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = String.format(Locale.US, "%02d", h),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isSelected) Color.White else IgniteTextPrimary
                                )
                            }
                        }
                    }
                }
            }

            // Minute Selection Row
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SELECT MINUTE (00 - 59)",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = IgniteTextSecondary
                    )

                    // Minute Fine-Tuning Step Buttons
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                val newMin = if (minute >= 5) minute - 5 else 59 - (4 - minute)
                                onTimeChanged(hour, (newMin + 60) % 60)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IgniteSurfaceVariant),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("-5m", fontSize = 11.sp, color = IgniteTextSecondary)
                        }

                        Button(
                            onClick = {
                                val newMin = if (minute > 0) minute - 1 else 59
                                onTimeChanged(hour, newMin)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IgniteSurfaceVariant),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("-1m", fontSize = 11.sp, color = IgniteTextSecondary)
                        }

                        Button(
                            onClick = {
                                val newMin = if (minute < 59) minute + 1 else 0
                                onTimeChanged(hour, newMin)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IgniteSurfaceVariant),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("+1m", fontSize = 11.sp, color = IgniteTextSecondary)
                        }

                        Button(
                            onClick = {
                                val newMin = (minute + 5) % 60
                                onTimeChanged(hour, newMin)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IgniteSurfaceVariant),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("+5m", fontSize = 11.sp, color = IgniteTextSecondary)
                        }
                    }
                }

                // Quick Minute Preset Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(0, 15, 30, 45).forEach { m ->
                        val isSelected = minute == m
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) IgniteFlameContainer else IgniteSurfaceVariant)
                                .border(
                                    1.dp,
                                    if (isSelected) IgniteFlamePrimary else Color.Transparent,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { onTimeChanged(hour, m) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = String.format(Locale.US, ":%02d", m),
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) IgniteFlameOrange else IgniteTextPrimary
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = IgniteOutline)

            // Full-Day Quick Presets (Covering morning, noon, afternoon, evening, night, midnight!)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "FULL-DAY QUICK PRESETS",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = IgniteTextMuted
                )

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val presets = listOf(
                        Triple(7, 0, "07:00 AM (Morning)"),
                        Triple(12, 0, "12:00 PM (Noon)"),
                        Triple(14, 30, "02:30 PM (Afternoon)"),
                        Triple(18, 0, "06:00 PM (Evening)"),
                        Triple(22, 30, "10:30 PM (Night)"),
                        Triple(0, 0, "12:00 AM (Midnight)")
                    )

                    presets.forEach { (presetH, presetM, label) ->
                        val isSelected = hour == presetH && minute == presetM
                        FilterChip(
                            selected = isSelected,
                            onClick = { onTimeChanged(presetH, presetM) },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IgniteFlameContainer,
                                selectedLabelColor = IgniteFlameOrange
                            )
                        )
                    }
                }
            }
        }
    }
}
