package com.example.ui.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.database.CalendarEventEntity
import com.example.ui.components.IgniteCard
import com.example.ui.components.TimeFormatter
import com.example.ui.theme.IgniteBackground
import com.example.ui.theme.IgniteFlameContainer
import com.example.ui.theme.IgniteFlameCrimson
import com.example.ui.theme.IgniteFlameOrange
import com.example.ui.theme.IgniteFlamePrimary
import com.example.ui.theme.IgniteOutline
import com.example.ui.theme.IgniteSurface
import com.example.ui.theme.IgniteSurfaceVariant
import com.example.ui.theme.IgniteTextMuted
import com.example.ui.theme.IgniteTextPrimary
import com.example.ui.theme.IgniteTextSecondary
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CalendarScreen(
    viewModel: CalendarViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    var showAddEventSheet by remember { mutableStateOf(false) }
    var editingEvent by remember { mutableStateOf<CalendarEventEntity?>(null) }
    var isSearchExpanded by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = IgniteBackground,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingEvent = null
                    showAddEventSheet = true
                },
                containerColor = IgniteFlamePrimary,
                contentColor = Color.White,
                shape = CircleShape
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Event", modifier = Modifier.size(28.dp))
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 18.dp),
            contentPadding = PaddingValues(top = 20.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header with Month, Navigation, and Today Button
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = uiState.currentMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.US)),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            ),
                            color = IgniteTextPrimary
                        )
                        Text(
                            text = "Offline Calendar",
                            style = MaterialTheme.typography.labelSmall,
                            color = IgniteFlameOrange
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { viewModel.prevMonth() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Previous Month", tint = IgniteTextSecondary)
                        }
                        Button(
                            onClick = { viewModel.goToToday() },
                            colors = ButtonDefaults.buttonColors(containerColor = IgniteSurfaceVariant),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Today", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = IgniteFlamePrimary)
                        }
                        IconButton(onClick = { viewModel.nextMonth() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next Month", tint = IgniteTextSecondary)
                        }
                        IconButton(onClick = { isSearchExpanded = !isSearchExpanded }) {
                            Icon(Icons.Default.Search, contentDescription = "Search", tint = IgniteTextSecondary)
                        }
                    }
                }
            }

            // Search Bar
            if (isSearchExpanded) {
                item {
                    OutlinedTextField(
                        value = uiState.searchQuery,
                        onValueChange = { viewModel.setSearchQuery(it) },
                        placeholder = { Text("Search events, notes, dates...") },
                        trailingIcon = {
                            if (uiState.searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = IgniteTextMuted)
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IgniteFlamePrimary,
                            unfocusedBorderColor = IgniteOutline,
                            focusedTextColor = IgniteTextPrimary,
                            unfocusedTextColor = IgniteTextPrimary
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Views: Month / Week / Day
            item {
                TabRow(
                    selectedTabIndex = when (uiState.calendarView) {
                        "WEEK" -> 1
                        "DAY" -> 2
                        else -> 0
                    },
                    containerColor = IgniteSurface,
                    contentColor = IgniteFlamePrimary,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[when (uiState.calendarView) {
                                "WEEK" -> 1
                                "DAY" -> 2
                                else -> 0
                            }]),
                            color = IgniteFlamePrimary
                        )
                    }
                ) {
                    Tab(
                        selected = uiState.calendarView == "MONTH",
                        onClick = { viewModel.setCalendarView("MONTH") },
                        text = { Text("Month", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = uiState.calendarView == "WEEK",
                        onClick = { viewModel.setCalendarView("WEEK") },
                        text = { Text("Week", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = uiState.calendarView == "DAY",
                        onClick = { viewModel.setCalendarView("DAY") },
                        text = { Text("Day", fontWeight = FontWeight.Bold) }
                    )
                }
            }

            // Filter Chips
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("ALL", "EVENTS", "ALARMS", "IMPORTANT").forEach { filter ->
                        FilterChip(
                            selected = uiState.activeFilter == filter,
                            onClick = { viewModel.setActiveFilter(filter) },
                            label = { Text(filter) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IgniteFlameContainer,
                                selectedLabelColor = IgniteFlameOrange
                            )
                        )
                    }
                }
            }

            // Important Countdowns Row
            if (uiState.importantCountdowns.isNotEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.HourglassEmpty, contentDescription = null, tint = IgniteFlameOrange, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "IMPORTANT COUNTDOWNS",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = IgniteFlameOrange
                            )
                        }

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(uiState.importantCountdowns) { item ->
                                IgniteCard(
                                    modifier = Modifier.width(200.dp),
                                    backgroundColor = IgniteSurfaceVariant
                                ) {
                                    Column {
                                        Text(
                                            text = item.title,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                            color = IgniteTextPrimary,
                                            maxLines = 1
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = if (item.isToday) "TODAY" else "${item.daysRemaining} days left",
                                            style = MaterialTheme.typography.titleLarge.copy(
                                                fontWeight = FontWeight.Black,
                                                color = IgniteFlamePrimary
                                            )
                                        )
                                        Text(
                                            text = item.targetDate,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = IgniteTextMuted
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Calendar Grid or Week view
            if (uiState.calendarView == "MONTH") {
                item {
                    MonthCalendarGrid(
                        yearMonth = uiState.currentMonth,
                        selectedDate = uiState.selectedDate,
                        events = uiState.events,
                        onDateSelected = { date -> viewModel.selectDate(date) }
                    )
                }
            } else if (uiState.calendarView == "WEEK") {
                item {
                    WeekCalendarStrip(
                        selectedDate = uiState.selectedDate,
                        events = uiState.events,
                        onDateSelected = { date -> viewModel.selectDate(date) }
                    )
                }
            }

            // Selected Date Schedule Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = uiState.selectedDate.format(DateTimeFormatter.ofPattern("EEEE, MMM d", Locale.US)),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = IgniteTextPrimary
                    )
                    TextButton(onClick = {
                        editingEvent = null
                        showAddEventSheet = true
                    }) {
                        Text("+ Add Event", color = IgniteFlameOrange, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Items for Selected Day
            val showEvents = uiState.activeFilter == "ALL" || uiState.activeFilter == "EVENTS" || uiState.activeFilter == "IMPORTANT"
            val showAlarms = uiState.activeFilter == "ALL" || uiState.activeFilter == "ALARMS"

            val displayEvents = if (uiState.activeFilter == "IMPORTANT") {
                uiState.selectedDayEvents.filter { it.important }
            } else {
                uiState.selectedDayEvents
            }

            if (showEvents) {
                items(displayEvents, key = { "ev_${it.id}" }) { event ->
                    EventCard(
                        event = event,
                        is24Hour = uiState.is24Hour,
                        onClick = {
                            editingEvent = event
                            showAddEventSheet = true
                        },
                        onDelete = { viewModel.deleteEvent(event) }
                    )
                }
            }

            if (showAlarms) {
                items(uiState.selectedDayAlarms, key = { "al_${it.id}" }) { alarm ->
                    AlarmScheduleCard(alarm = alarm, is24Hour = uiState.is24Hour)
                }
            }

            if (displayEvents.isEmpty() && (!showAlarms || uiState.selectedDayAlarms.isEmpty())) {
                item {
                    IgniteCard(
                        modifier = Modifier.fillMaxWidth(),
                        backgroundColor = IgniteSurface
                    ) {
                        Text(
                            text = "No events or alarms scheduled for this date.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = IgniteTextMuted,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    }
                }
            }
        }
    }

    if (showAddEventSheet) {
        AddEditEventSheet(
            event = editingEvent,
            initialDate = uiState.selectedDate,
            onDismiss = { showAddEventSheet = false },
            onSave = { savedEvent ->
                viewModel.saveEvent(savedEvent) {
                    showAddEventSheet = false
                }
            }
        )
    }
}

@Composable
private fun MonthCalendarGrid(
    yearMonth: YearMonth,
    selectedDate: LocalDate,
    events: List<CalendarEventEntity>,
    onDateSelected: (LocalDate) -> Unit
) {
    IgniteCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = IgniteSurface
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Days of week header
            val daysOfWeek = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
            Row(modifier = Modifier.fillMaxWidth()) {
                daysOfWeek.forEach { dow ->
                    Text(
                        text = dow,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = IgniteTextSecondary
                    )
                }
            }

            val firstDayOfMonth = yearMonth.atDay(1)
            val firstDayOfWeek = firstDayOfMonth.dayOfWeek.value // 1=Mon .. 7=Sun
            val daysInMonth = yearMonth.lengthOfMonth()

            var currentDay = 1
            for (week in 0..5) {
                if (currentDay > daysInMonth) break
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (dayCol in 1..7) {
                        if ((week == 0 && dayCol < firstDayOfWeek) || currentDay > daysInMonth) {
                            Box(modifier = Modifier.weight(1f).aspectRatio(1f))
                        } else {
                            val thisDate = yearMonth.atDay(currentDay)
                            val isSelected = thisDate == selectedDate
                            val isToday = thisDate == LocalDate.now()
                            val hasEvents = events.any { it.date == thisDate.toString() }
                            val hasImportant = events.any { it.date == thisDate.toString() && it.important }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .clip(CircleShape)
                                    .background(
                                        if (isSelected) IgniteFlamePrimary
                                        else if (isToday) IgniteFlameContainer
                                        else Color.Transparent
                                    )
                                    .clickable { onDateSelected(thisDate) },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "$currentDay",
                                        fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.White else if (isToday) IgniteFlameOrange else IgniteTextPrimary,
                                        fontSize = 14.sp
                                    )
                                    if (hasEvents) {
                                        Box(
                                            modifier = Modifier
                                                .size(4.dp)
                                                .clip(CircleShape)
                                                .background(if (hasImportant) Color(0xFFFFD700) else if (isSelected) Color.White else IgniteFlameOrange)
                                        )
                                    }
                                }
                            }
                            currentDay++
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WeekCalendarStrip(
    selectedDate: LocalDate,
    events: List<CalendarEventEntity>,
    onDateSelected: (LocalDate) -> Unit
) {
    val startOfWeek = selectedDate.minusDays((selectedDate.dayOfWeek.value - 1).toLong())
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        for (i in 0..6) {
            val date = startOfWeek.plusDays(i.toLong())
            val isSelected = date == selectedDate
            val isToday = date == LocalDate.now()
            val hasEvents = events.any { it.date == date.toString() }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSelected) IgniteFlamePrimary else IgniteSurfaceVariant)
                    .clickable { onDateSelected(date) }
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = date.dayOfWeek.name.take(3),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isSelected) Color.White else IgniteTextSecondary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${date.dayOfMonth}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (isSelected) Color.White else IgniteTextPrimary
                )
                if (hasEvents) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .size(4.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) Color.White else IgniteFlameOrange)
                    )
                }
            }
        }
    }
}

@Composable
private fun EventCard(
    event: CalendarEventEntity,
    is24Hour: Boolean,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    IgniteCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        backgroundColor = IgniteSurfaceVariant
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (event.important) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Starred",
                            tint = Color(0xFFFFD700),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text(
                        text = event.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = IgniteTextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = if (event.allDay) "All Day" else "${event.startTime} - ${event.endTime}",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                    color = IgniteFlameOrange
                )

                if (event.description.isNotBlank()) {
                    Text(
                        text = event.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = IgniteTextSecondary,
                        maxLines = 2
                    )
                }
            }

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Event", tint = IgniteTextMuted)
            }
        }
    }
}

@Composable
private fun AlarmScheduleCard(
    alarm: com.example.data.database.AlarmEntity,
    is24Hour: Boolean
) {
    IgniteCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = IgniteSurface
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Alarm, contentDescription = null, tint = IgniteFlamePrimary)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${TimeFormatter.formatTime(alarm.hour, alarm.minute, is24Hour)} — ${alarm.label}",
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                    color = IgniteTextPrimary
                )
                Text(
                    text = "Sound: ${alarm.soundName} • Mission: ${alarm.missionType}",
                    style = MaterialTheme.typography.bodySmall,
                    color = IgniteTextMuted
                )
            }
        }
    }
}
