package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.IgniteFlameCrimson
import com.example.ui.theme.IgniteFlameOrange
import com.example.ui.theme.IgniteFlamePrimary
import com.example.ui.theme.IgniteSurface
import com.example.ui.theme.IgniteSurfaceVariant
import com.example.ui.theme.IgniteTextMuted
import com.example.ui.theme.IgniteTextPrimary
import com.example.ui.theme.IgniteTextSecondary
import com.example.ui.theme.PriorityHigh
import com.example.ui.theme.PriorityLow
import com.example.ui.theme.PriorityMedium
import kotlinx.coroutines.delay
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun IgniteDigitalClock(
    modifier: Modifier = Modifier,
    is24Hour: Boolean = false
) {
    var currentTime by remember { mutableStateOf(LocalTime.now()) }

    LaunchedEffect(Unit) {
        while (true) {
            currentTime = LocalTime.now()
            delay(1000L)
        }
    }

    val timeString = remember(currentTime, is24Hour) {
        if (is24Hour) {
            currentTime.format(DateTimeFormatter.ofPattern("HH:mm:ss"))
        } else {
            currentTime.format(DateTimeFormatter.ofPattern("hh:mm:ss"))
        }
    }

    val amPmString = remember(currentTime, is24Hour) {
        if (is24Hour) "" else currentTime.format(DateTimeFormatter.ofPattern("a", Locale.US))
    }

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.Center
    ) {
        Text(
            text = timeString,
            style = MaterialTheme.typography.displayLarge.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                fontFamily = FontFamily.Monospace
            ),
            color = IgniteTextPrimary
        )
        if (amPmString.isNotEmpty()) {
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = amPmString,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold
                ),
                color = IgniteFlamePrimary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }
}

@Composable
fun IgniteLogoHeader(
    modifier: Modifier = Modifier,
    showTagline: Boolean = true
) {
    val infiniteTransition = rememberInfiniteTransition(label = "flame_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "flame_scale"
    )

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(IgniteFlameOrange, IgniteFlamePrimary, IgniteFlameCrimson)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.LocalFireDepartment,
                    contentDescription = "Ignite Flame",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "IGNITE",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 4.sp
                ),
                color = IgniteTextPrimary
            )
        }

        if (showTagline) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Wake. Rise. Ignite.",
                style = MaterialTheme.typography.bodySmall.copy(
                    letterSpacing = 1.5.sp,
                    fontWeight = FontWeight.Medium
                ),
                color = IgniteTextSecondary
            )
        }
    }
}

@Composable
fun IgniteCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color = IgniteSurfaceVariant,
    borderColor: Color? = null,
    content: @Composable () -> Unit
) {
    val borderModifier = if (borderColor != null) {
        Modifier.border(1.dp, borderColor, RoundedCornerShape(20.dp))
    } else {
        Modifier
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(backgroundColor)
            .then(borderModifier)
            .padding(16.dp)
    ) {
        content()
    }
}

@Composable
fun PriorityBadge(priority: String) {
    val (color, text) = when (priority.uppercase()) {
        "HIGH" -> PriorityHigh to "HIGH"
        "MEDIUM" -> PriorityMedium to "MED"
        else -> PriorityLow to "LOW"
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = color
        )
    }
}

object TimeFormatter {
    fun formatTime(hour: Int, minute: Int, is24Hour: Boolean = false): String {
        return if (is24Hour) {
            String.format(Locale.US, "%02d:%02d", hour, minute)
        } else {
            val h = if (hour == 0) 12 else if (hour > 12) hour - 12 else hour
            val amPm = if (hour < 12) "AM" else "PM"
            String.format(Locale.US, "%02d:%02d %s", h, minute, amPm)
        }
    }
}
