package com.example.data.repository

import com.example.data.database.CalendarEventDao
import com.example.data.database.CalendarEventEntity
import kotlinx.coroutines.flow.Flow

class CalendarRepository(private val calendarEventDao: CalendarEventDao) {
    val allEvents: Flow<List<CalendarEventEntity>> = calendarEventDao.getAllEventsFlow()

    fun getEventsForDate(date: String): Flow<List<CalendarEventEntity>> =
        calendarEventDao.getEventsForDateFlow(date)

    suspend fun getEventsForDateSync(date: String): List<CalendarEventEntity> =
        calendarEventDao.getEventsForDate(date)

    fun getUpcomingImportantEvents(currentDate: String): Flow<List<CalendarEventEntity>> =
        calendarEventDao.getUpcomingImportantEvents(currentDate)

    fun searchEvents(query: String): Flow<List<CalendarEventEntity>> =
        calendarEventDao.searchEventsFlow(query)

    suspend fun getEventById(id: Long): CalendarEventEntity? =
        calendarEventDao.getEventById(id)

    suspend fun insertEvent(event: CalendarEventEntity): Long =
        calendarEventDao.insertEvent(event)

    suspend fun updateEvent(event: CalendarEventEntity) =
        calendarEventDao.updateEvent(event)

    suspend fun deleteEvent(event: CalendarEventEntity) =
        calendarEventDao.deleteEvent(event)

    suspend fun deleteEventById(id: Long) =
        calendarEventDao.deleteEventById(id)
}
