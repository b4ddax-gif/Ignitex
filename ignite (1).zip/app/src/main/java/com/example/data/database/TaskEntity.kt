package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val date: String, // "yyyy-MM-dd"
    val priority: String = "MEDIUM", // LOW, MEDIUM, HIGH
    val completed: Boolean = false,
    val reminderTime: String? = null, // "HH:mm" or null
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
