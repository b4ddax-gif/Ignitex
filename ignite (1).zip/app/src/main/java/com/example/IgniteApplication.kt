package com.example

import android.app.Application
import com.example.alarm.AlarmScheduler
import com.example.calendar.CalendarScheduler
import com.example.data.database.AppDatabase
import com.example.data.repository.AlarmRepository
import com.example.data.repository.CalendarRepository
import com.example.data.repository.HistoryRepository
import com.example.data.repository.SettingsRepository
import com.example.data.repository.TaskRepository
import com.example.notifications.NotificationHelper

class IgniteApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var alarmRepository: AlarmRepository
        private set

    lateinit var calendarRepository: CalendarRepository
        private set

    lateinit var taskRepository: TaskRepository
        private set

    lateinit var historyRepository: HistoryRepository
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var alarmScheduler: AlarmScheduler
        private set

    lateinit var calendarScheduler: CalendarScheduler
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        NotificationHelper.createNotificationChannels(this)

        database = AppDatabase.getDatabase(this)
        alarmRepository = AlarmRepository(database.alarmDao())
        calendarRepository = CalendarRepository(database.calendarEventDao())
        taskRepository = TaskRepository(database.taskDao())
        historyRepository = HistoryRepository(database.alarmHistoryDao(), database.streakDao())
        settingsRepository = SettingsRepository(this)
        alarmScheduler = AlarmScheduler(this)
        calendarScheduler = CalendarScheduler(this)
    }

    companion object {
        lateinit var instance: IgniteApplication
            private set
    }
}
