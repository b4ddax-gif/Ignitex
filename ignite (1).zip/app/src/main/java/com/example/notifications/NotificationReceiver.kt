package com.example.notifications

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

class NotificationReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        when (action) {
            ACTION_EVENT_REMINDER -> {
                val eventId = intent.getLongExtra(EXTRA_EVENT_ID, 0L)
                val title = intent.getStringExtra(EXTRA_TITLE) ?: "Calendar Event"
                val time = intent.getStringExtra(EXTRA_TIME) ?: ""

                val notification = NotificationCompat.Builder(context, NotificationHelper.CHANNEL_REMINDERS)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle("Event: $title")
                    .setContentText(if (time.isNotBlank()) "Upcoming at $time" else "Event starting soon")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setAutoCancel(true)
                    .setContentIntent(pendingIntent)
                    .build()

                notificationManager.notify((200000 + eventId).toInt(), notification)
            }

            ACTION_TASK_REMINDER -> {
                val taskId = intent.getLongExtra(EXTRA_TASK_ID, 0L)
                val title = intent.getStringExtra(EXTRA_TITLE) ?: "Task Reminder"

                val notification = NotificationCompat.Builder(context, NotificationHelper.CHANNEL_REMINDERS)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle("Task: $title")
                    .setContentText("Don't forget your scheduled task")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setAutoCancel(true)
                    .setContentIntent(pendingIntent)
                    .build()

                notificationManager.notify((300000 + taskId).toInt(), notification)
            }
        }
    }

    companion object {
        const val ACTION_EVENT_REMINDER = "com.aistudio.ignite.ACTION_EVENT_REMINDER"
        const val ACTION_TASK_REMINDER = "com.aistudio.ignite.ACTION_TASK_REMINDER"

        const val EXTRA_EVENT_ID = "extra_event_id"
        const val EXTRA_TASK_ID = "extra_task_id"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_TIME = "extra_time"
    }
}
