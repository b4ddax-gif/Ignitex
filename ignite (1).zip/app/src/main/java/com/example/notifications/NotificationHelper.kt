package com.example.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Color
import android.os.Build

object NotificationHelper {
    const val CHANNEL_ALARMS = "ignite_alarms_channel"
    const val CHANNEL_REMINDERS = "ignite_reminders_channel"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Alarms Channel
            val alarmChannel = NotificationChannel(
                CHANNEL_ALARMS,
                "IGNITE Alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Full-screen alarms and ringing alerts"
                enableLights(true)
                lightColor = Color.parseColor("#FF5722")
                enableVibration(true)
                setBypassDnd(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Reminders Channel
            val reminderChannel = NotificationChannel(
                CHANNEL_REMINDERS,
                "Events & Tasks",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Reminders for scheduled calendar events and planner tasks"
                enableLights(true)
                lightColor = Color.parseColor("#FF5722")
            }

            notificationManager.createNotificationChannel(alarmChannel)
            notificationManager.createNotificationChannel(reminderChannel)
        }
    }
}
